@echo off
chcp 65001 >nul
cd /d "%~dp0"
title АкБарак — установка
echo ============================================
echo   АкБарак: установка программ для терминала
echo ============================================
echo.

REM ---------- 1. Python 3.12 ----------
python --version >nul 2>nul
if %errorlevel%==0 (
  echo [1/3] Python уже установлен:
  python --version
) else (
  echo [1/3] Ставлю Python 3.12 ...
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo.
    echo  Не получилось поставить Python автоматически.
    echo  Скачай вручную: https://www.python.org/downloads/release/python-31210/
    echo  Файл "Windows installer 64-bit". При установке ОБЯЗАТЕЛЬНО галочка "Add python.exe to PATH".
    echo  Потом закрой это окно и запусти 1_USTANOVKA.bat ещё раз.
    pause
    exit /b
  )
  echo.
  echo  Python поставлен. ЗАКРОЙ это окно и запусти 1_USTANOVKA.bat ЕЩЁ РАЗ.
  pause
  exit /b
)
echo.

REM ---------- 2. Библиотеки ----------
echo [2/3] Ставлю библиотеки (requests, pywin32, pillow, pypdf, qrcode) ...
python -m pip install --no-index --find-links wheels requests pywin32 pillow pypdf qrcode
if errorlevel 1 python -m pip install requests pywin32 pillow pypdf qrcode
echo.

REM ---------- 3. SumatraPDF ----------
if exist "%LOCALAPPDATA%\SumatraPDF\SumatraPDF.exe" (
  echo [3/3] SumatraPDF уже установлен.
) else if exist "%ProgramFiles%\SumatraPDF\SumatraPDF.exe" (
  echo [3/3] SumatraPDF уже установлен.
) else (
  echo [3/3] Ставлю SumatraPDF ^(печать PDF^) ...
  winget install -e --id SumatraPDF.SumatraPDF --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo  Не получилось. Скачай вручную: https://www.sumatrapdfreader.org/download-free-pdf-viewer
    echo  ^(64-bit installer^), установи и всё.
  )
)
echo.
echo ============================================
echo   Готово!
echo   Дальше:
echo   - сделай принтер "по умолчанию" ^(см. INSTRUKCIYA.txt^)
echo   - запусти 2_ZAPUSK_PECHATI.bat
echo ============================================
pause
